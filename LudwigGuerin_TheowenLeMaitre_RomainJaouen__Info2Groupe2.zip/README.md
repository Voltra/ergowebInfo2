Ludwig GUERIN

Théowen LE MAITRE

Romain JAOUEN



Info 2 Groupe 2



# Ergo Web

La page d'accueil correspond au fichier `public_html/index.html`.