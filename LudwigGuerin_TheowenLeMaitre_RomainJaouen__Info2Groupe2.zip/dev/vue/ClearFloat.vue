<script>
	export default {
		name: "clear-float",
		render(h){
			return (
				<div class="clear_float"></div>
			);
		}
	};
</script>

<style scoped>
	@import "~@css/_components/clearFloat/clearFloat";
</style>